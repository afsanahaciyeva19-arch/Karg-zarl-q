ELEKTRON KARGÜZARLIQ - PWA

Bu ZIP-i GitHub Pages və ya Netlify üçün istifadə edə bilərsiniz.

GitHub Pages üçün:
1. ZIP-i açın.
2. index.html, manifest.webmanifest, sw.js və icons qovluğunu repository-yə yükləyin.
3. GitHub Pages linkini açın.
4. Android/Chrome/Edge və kompüterdə “Install app / Tətbiqi quraşdır”.
5. iPhone/iPad: Safari > Share > Add to Home Screen.

Netlify üçün:
ZIP-i bütöv şəkildə deploy edin.

Qeyd:
PWA quraşdırılması üçün sayt HTTPS üzərindən açılmalıdır.
