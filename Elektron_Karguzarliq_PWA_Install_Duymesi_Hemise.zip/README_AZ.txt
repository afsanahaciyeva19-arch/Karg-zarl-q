
Netlify badge:
Bu versiyada HTML daxilində mümkün Netlify badge elementləri təmizlənib və əlavə gizlətmə qaydası var.
Əgər badge yenə görünərsə, Netlify Project configuration bölməsində "Powered by Netlify badge" seçimini də deaktiv edin.


YENİ:
Bu versiyada “📲 Tətbiqi quraşdır” düyməsi HƏMİŞƏ görünür.
Brauzer PWA quraşdırma pəncərəsini dəstəkləyirsə, düyməyə basanda birbaşa açılır.
Dəstəkləmirsə, düymə Android/iPhone üçün quraşdırma təlimatını göstərir.
